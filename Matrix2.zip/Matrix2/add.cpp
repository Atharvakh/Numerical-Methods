#include <iostream>
#include "matrix.hpp"

Matrix Matrix::Add(const Matrix &m)
{
    if (this->rows != m.rows || this->cols != m.cols)
    {
        throw std::runtime_error("Matrix dimensions do not match for addition.");
    }

    Matrix result(this->rows, this->cols);
    for (int i = 0; i < this->rows; ++i)
    {
        for (int j = 0; j < this->cols; ++j)
        {
            result.mat[i][j] = this->mat[i][j] + m.mat[i][j];
        }
    }
    return result;
}

Matrix Matrix::Subtract(const Matrix &m)
{
    if (this->rows != m.rows || this->cols != m.cols)
    {
        throw std::runtime_error("Matrix dimensions do not match for addition.");
    }

    Matrix result(this->rows, this->cols);
    for (int i = 0; i < this->rows; ++i)
    {
        for (int j = 0; j < this->cols; ++j)
        {
            result.mat[i][j] = this->mat[i][j] - m.mat[i][j];
        }
    }
    return result;
}

// Matrix Matrix::Multiply(const Matrix &m)
// {
//     if (this->cols != m.rows)
//     {
//         throw runtime_error("Matrix dimensions do not allow multiplication.");
//     }

//     Matrix result(this->rows, m.cols);
//     for (int i = 0; i < this->rows; ++i)
//     {
//         for (int j = 0; j < m.cols; ++j)
//         {
//             result.mat[i][j] = 0;
//             for (int k = 0; k < this->cols; ++k)
//             {
//                 result.mat[i][j] += this->mat[i][k] * m.mat[k][j];
//             }
//         }
//     }
//     return result;
// }

// bool Matrix::isidentity()
// {
//     if (rows != cols)
//         return false;
//     for (int i = 0; i < rows; ++i)
//     {
//         for (int j = 0; j < cols; ++j)
//         {
//             if ((i == j && mat[i][j] != 1) || (i != j && mat[i][j] != 0))
//             {
//                 return false;
//             }
//         }
//     }
//     return true;
// }

// bool Matrix::isSymmetric()
// {
//     if (rows != cols)
//         return false;
//     for (int i = 0; i < rows; ++i)
//     {
//         for (int j = 0; j < cols; ++j)
//         {
//             if (mat[i][j] != mat[j][i])
//             {
//                 return false;
//             }
//         }
//     }
//     return true;
// }