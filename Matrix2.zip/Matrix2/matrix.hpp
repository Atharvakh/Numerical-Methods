#include "iostream"
#include <fstream>
using namespace std;

class Matrix
{
public:
    int rows, cols;
    double **mat;
    Matrix();
    Matrix(int, int);
    ~Matrix();
    Matrix(const std::string &filename);
    Matrix(Matrix &m);
    void Display() const;
    Matrix Add(const Matrix &m);
    Matrix Subtract(const Matrix &m);
    // Matrix Multiply(const Matrix &m);
    // bool isidentity();
    // bool isSymmetric();
};