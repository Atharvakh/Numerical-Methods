#include "matrix.hpp"
#include <iostream>
using namespace std;

int main()
{
    Matrix m1("matrix1.txt");
    Matrix m2("matrix2.txt");
    Matrix result(m1.rows, m1.cols);

    std::cout << "Matrix 1:" << std::endl;
    m1.Display();

    std::cout << "Matrix 2:" << std::endl;
    m2.Display();

    result = m1.Add(m2);
    std::cout << "Result of addition:" << std::endl;
    result.Display();

    result = m1.Subtract(m2);
    std::cout << "Result of subtraction:" << std::endl;
    result.Display();

    return 0;
}
